<header class="header">

   <section class="flex">

      <a href="#home" class="logo"><span>PIZZA</span>DIM</a>

      <nav class="navbar">
         <a href="index.php#home">Home</a>
         <a href="index.php#about">About</a>
         <a href="menu.php">Menu</a>
      </nav>

      <div class="icons">
         <div id="menu-btn" class="fas fa-bars"></div>
         <div id="user-btn" class="fas fa-user"></div>
         <div id="order-btn" class="fas fa-box"></div>
         <?php
            $count_cart_items = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
            $count_cart_items->execute([$user_id]);
            $total_cart_items = $count_cart_items->rowCount();
         ?>
         <div id="cart-btn" class="fas fa-shopping-cart"><span>(<?= $total_cart_items; ?>)</span></div>
      </div>

   </section>

</header>
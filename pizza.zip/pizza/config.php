<?php

   $db_name = "mysql:host=localhost;dbname=pizza";
   $username = "root";
   $password = "menurutNgana88";

   $conn = new PDO($db_name, $username, $password);

?>
<?php
include 'config.php';

session_start();

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';

include 'header.php';
include 'popups.php';

$message = [];

if (isset($_POST['add_to_cart'])) {
   if ($user_id == '') {
      $message[] = 'Silakan login terlebih dahulu!';
   } else {
      $pid = $_POST['pid'];
      $name = $_POST['name'];
      $price = $_POST['price'];
      $image = $_POST['image'];
      $qty = htmlspecialchars($_POST['qty'], ENT_QUOTES, 'UTF-8');

      $select_cart = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND name = ?");
      $select_cart->execute([$user_id, $name]);

      if ($select_cart->rowCount() > 0) {
         $message[] = 'Item sudah ada di keranjang!';
      } else {
         $insert_cart = $conn->prepare("INSERT INTO cart (user_id, pid, name, price, quantity, image) VALUES(?,?,?,?,?,?)");
         $insert_cart->execute([$user_id, $pid, $name, $price, $qty, $image]);
         $message[] = 'Berhasil ditambahkan ke keranjang!';
      }
   }
}

if(isset($_POST['order'])){

   if($user_id == ''){
      $message[] = 'silahkan masuk terlebih dahulu!';
   }else{
      $name = $_POST['name'];
      $name = filter_var($name, FILTER_SANITIZE_STRING);
      $number = $_POST['number'];
      $number = filter_var($number, FILTER_SANITIZE_STRING);
      $address = $_POST['flat'].', '.$_POST['street'].' - '.$_POST['pin_code'];
      $address = filter_var($address, FILTER_SANITIZE_STRING);
      $method = $_POST['method'];
      $method = filter_var($method, FILTER_SANITIZE_STRING);
      $total_price = $_POST['total_price'];
      $total_products = $_POST['total_products'];

      $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
      $select_cart->execute([$user_id]);

      if($select_cart->rowCount() > 0){
         $insert_order = $conn->prepare("INSERT INTO `orders`(user_id, name, number, method, address, total_products, total_price) VALUES(?,?,?,?,?,?,?)");
         $insert_order->execute([$user_id, $name, $number, $method, $address, $total_products, $total_price]);
         $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
         $delete_cart->execute([$user_id]);
         $message[] = 'pesanan berhasil ditempatkan!';

         header('Location: receipt.php');
      }else{
         $message[] = 'keranjang anda kosong!';
      }
   }

}
?>

<!DOCTYPE html>
<html lang="id">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Menu PizzaDim</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="/PIZZA/css/style.css">
</head>
<body>

<!-- Notifikasi -->
<?php if (!empty($message)) : ?>
   <?php foreach ($message as $msg) : ?>
      <div class="message">
         <span><?= $msg ?></span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
   <?php endforeach; ?>
<?php endif; ?>

<!-- Menu Section -->
<section id="menu" class="menu">
   <h1 class="heading">Menu PizzaDim</h1>

   <div class="box-container">
      <?php
     $menus = [
   ["id" => 1, "name" => "Margherita", "price" => "50000", "image" => "/PIZZA/projects images/pizza-1.jpg"],
   ["id" => 2, "name" => "Pepperoni", "price" => "60000", "image" => "/PIZZA/projects images/pizza-2.jpg"],
   ["id" => 3, "name" => "Hawaiian", "price" => "65000", "image" => "/PIZZA/projects images/pizza-3.jpg"],
   ["id" => 4, "name" => "Veggie", "price" => "55000", "image" => "/PIZZA/projects images/pizza-4.jpg"],
   ["id" => 5, "name" => "Mushroom", "price" => "70000", "image" => "/PIZZA/projects images/pizza-5.jpg"],
   ["id" => 6, "name" => "Meat Lovers", "price" => "75000", "image" => "/PIZZA/projects images/pizza-6.jpg"],
   ["id" => 7, "name" => "BBQ Chicken", "price" => "72000", "image" => "/PIZZA/projects images/pizza-7.jpg"],
   ["id" => 8, "name" => "Cheese Burst", "price" => "68000", "image" => "/PIZZA/projects images/pizza-8.jpg"],
   ["id" => 9, "name" => "Tuna Delight", "price" => "66000", "image" => "/PIZZA/projects images/pizza-9.jpg"],
   ["id" => 10, "name" => "Hot & Spicy", "price" => "69000", "image" => "/PIZZA/projects images/pizza-10.jpg"],
   ["id" => 11, "name" => "Italian Sausage", "price" => "73000", "image" => "/PIZZA/projects images/pizza-11.jpg"],
   ["id" => 12, "name" => "Four Cheese", "price" => "71000", "image" => "/PIZZA/projects images/pizza-12.jpg"]
];

      foreach ($menus as $menu) :
      ?>
         <div class="box">
            <div class="price">Rp <?= number_format($menu["price"], 0, ',', '.'); ?></div>
            <img src="<?= $menu["image"]; ?>" alt="<?= $menu["name"]; ?>">
            <div class="name"><?= $menu["name"]; ?></div>
            <form action="" method="post">
               <input type="hidden" name="pid" value="<?= $menu["id"]; ?>">
               <input type="hidden" name="name" value="<?= $menu["name"]; ?>">
               <input type="hidden" name="price" value="<?= $menu["price"]; ?>">
               <input type="hidden" name="image" value="<?= $menu["image"]; ?>">
               <input type="number" name="qty" class="qty" min="0" max="99" value="0" onkeypress="if(this.value.length == 2) return false;">
               <input type="submit" class="btn" name="add_to_cart" value="Tambah ke Keranjang">
            </form>
         </div>
      <?php endforeach; ?>
   </div>
</section>


</section>


<!-- JS -->
<script src="/PIZZA/js/script.js"></script>

</body>
</html>

<?php
ob_start();

include 'config.php';

session_start();

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';

include 'header.php';
include 'popups.php';

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['register'])){

   $name = $_POST['name'];
   $name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
   $email = $_POST['email'];
   $email = htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8');
   $pass = sha1($_POST['pass']);
   $pass = htmlspecialchars($pass, ENT_QUOTES, 'UTF-8');
   $cpass = sha1($_POST['cpass'] );
   $cpass = htmlspecialchars($cpass, ENT_QUOTES, 'UTF-8');

   $select_user = $conn->prepare("SELECT * FROM user WHERE name = ? AND email = ?");
   $select_user->execute([$name, $email]);

   if($select_user->rowCount() > 0){
      $message[] = 'nama pengguna atau email sudah ada!';
   }else{
      if($pass != $cpass){
         $message[] = 'konfirmasi kata sandi tidak cocok!';
      }else{
         $insert_user = $conn->prepare("INSERT INTO user (name, email, password) VALUES(?,?,?)");
         $insert_user->execute([$name, $email, $cpass]);
         $message[] = 'berhasil terdaftar, silakan masuk sekarang!';
      }
   }

}

if(isset($_POST['update_qty'])){
   $cart_id = $_POST['cart_id'];
   $qty = $_POST['qty'];
   $qty = filter_var($qty, FILTER_UNSAFE_RAW, FILTER_FLAG_STRIP_LOW | FILTER_FLAG_STRIP_HIGH);
   $update_qty = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
   $update_qty->execute([$qty, $cart_id]);
   $message[] = 'jumlah keranjang diperbarui!';
}

if(isset($_GET['delete_cart_item'])){
   $delete_cart_id = $_GET['delete_cart_item'];
   $delete_cart_item = $conn->prepare("DELETE FROM cart WHERE id = ?");
   $delete_cart_item->execute([$delete_cart_id]);
   header('location:index.php');
}

if(isset($_GET['logout'])){
   session_unset();
   session_destroy();
   header('location:index.php');
}

if(isset($_POST['add_to_cart'])){

   if($user_id == ''){
      $message[] = 'silahkan masuk terlebih dahulu!';
   }else{

      $pid = $_POST['pid'];
      $name = $_POST['name'];
      $price = $_POST['price'];
      $image = $_POST['image'];
      $qty = $_POST['qty'];
      $qty = filter_var($qty, FILTER_UNSAFE_RAW, FILTER_FLAG_STRIP_LOW | FILTER_FLAG_STRIP_HIGH);

      $select_cart = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND name = ?");
      $select_cart->execute([$user_id, $name]);

      if($select_cart->rowCount() > 0){
         $message[] = 'sudah ditambahkan ke troli';
      }else{
         $insert_cart = $conn->prepare("INSERT INTO cart (user_id, pid, name, price, quantity, image) VALUES(?,?,?,?,?,?)");
         $insert_cart->execute([$user_id, $pid, $name, $price, $qty, $image]);
         $message[] = 'ditambahkan ke keranjang!';
      }

   }

}

if(isset($_POST['order'])){

   if($user_id == ''){
      $message[] = 'silahkan masuk terlebih dahulu!';
   }else{
      $name = $_POST['name'];
      $name = filter_var($name, FILTER_SANITIZE_STRING);
      $number = $_POST['number'];
      $number = filter_var($number, FILTER_SANITIZE_STRING);
      $address = $_POST['flat'].', '.$_POST['street'].' - '.$_POST['pin_code'];
      $address = filter_var($address, FILTER_SANITIZE_STRING);
      $method = $_POST['method'];
      $method = filter_var($method, FILTER_SANITIZE_STRING);
      $total_price = $_POST['total_price'];
      $total_products = $_POST['total_products'];

      $select_cart = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
      $select_cart->execute([$user_id]);

      if($select_cart->rowCount() > 0){
         $insert_order = $conn->prepare("INSERT INTO orders (user_id, name, number, method, address, total_products, total_price) VALUES(?,?,?,?,?,?,?)");
         $insert_order->execute([$user_id, $name, $number, $method, $address, $total_products, $total_price]);
         $delete_cart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
         $delete_cart->execute([$user_id]);
         $message[] = 'pesanan berhasil ditempatkan!';

         header('Location: receipt.php');
      }else{
         $message[] = 'keranjang anda kosong!';
      }
   }

}
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>PizzaDim</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="/PIZZA/css/style.css">

</head>
<body>

<?php
   if(isset($message)){
      foreach($message as $message){
         echo '
         <div class="message">
            <span>'.$message.'</span>
            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
         </div>
         ';
      }
   }
?>

<div class="home-bg">

   <section class="home" id="home">

      <div class="slide-container">

         <div class="slide active">
            <div class="image">
               <img src="/PIZZA/images/home-img-1.png" alt="">
            </div>
            <div class="content">
               <h3>Rasakan Pizza Terbaik di PizzaDim</h3>
               <div class="fas fa-angle-left" onclick="prev()"></div>
               <div class="fas fa-angle-right" onclick="next()"></div>
            </div>
         </div>

         <div class="slide">
            <div class="image">
               <img src="/PIZZA/images/home-img-2.png" alt="">
            </div>
            <div class="content">
               <h3>Nikmati kelezatan pizza terbaik kami</h3>
               <div class="fas fa-angle-left" onclick="prev()"></div>
               <div class="fas fa-angle-right" onclick="next()"></div>
            </div>
         </div>

         <div class="slide">
            <div class="image">
               <img src="/PIZZA/images/home-img-3.png" alt="">
            </div>
            <div class="content">
               <h3>Dibuat dengan hati dan cinta</h3>
               <div class="fas fa-angle-left" onclick="prev()"></div>
               <div class="fas fa-angle-right" onclick="next()"></div>
            </div>
         </div>

      </div>

   </section>

</div>

<!-- about section starts  -->

<section class="about" id="about">

   <h1 class="heading">tentang kami</h1>

   <div class="box-container">

      <div class="box">
         <img src="/PIZZA/images/about-1.svg" alt="">
         <h3>Dibuat dengan hati dan cinta</h3>
         <p>Setiap potongan pizza kami dibuat dengan bahan berkualitas dan dedikasi, memberikan pengalaman rasa yang otentik dan memuaskan untuk setiap pelanggan kami.</p>
         <a href="#menu" class="btn">menu kami</a>
      </div>

      <div class="box">
         <img src="/PIZZA/images/about-2.svg" alt="">
         <h3>Malam yang sibuk? PizzaDim solusinya! </h3>
         <p>Nikmati kelezatan pizza berkualitas tanpa repot memasak. Pesan online atau melalui telepon, dan kami akan mengantarkan pizza panas dan lezat langsung ke depan pintu Anda. </p>
         <a href="#menu" class="btn">menu kami</a>
      </div>

      <div class="box">
         <img src="/PIZZA/images/about-3.svg" alt="">
         <h3>berbagi dengan teman-teman</h3>
         <p>Nikmati kelezatan pizza terbaik kami, sempurna untuk berbagi! Tidak ada yang lebih menyenangkan daripada menikmati hidangan lezat bersama teman dan keluarga. </p>
         <a href="#menu" class="btn">menu kami</a>
      </div>

   </div>

</section>


<!-- menu section starts  -->

<section id="menu" class="menu">

   <h1 class="heading">Menu PizzaDim Terbaru</h1>

   <div class="box-container">

      <?php
         // Daftar menu PizzaDim
         $menus = [
            ["id" => 1, "name" => "Margherita", "price" => "50000", "image" => "/PIZZA/projects images/pizza-1.jpg"],
            ["id" => 2, "name" => "Pepperoni", "price" => "60000", "image" => "/PIZZA/projects images/pizza-2.jpg"],
            ["id" => 3, "name" => "Hawaiian", "price" => "65000", "image" => "/PIZZA/projects images/pizza-3.jpg"],
            ["id" => 4, "name" => "Veggie", "price" => "55000", "image" => "/PIZZA/projects images/pizza-4.jpg"],
            ["id" => 5, "name" => "Mushroom", "price" => "70000", "image" => "/PIZZA/projects images/pizza-5.jpg"],
            ["id" => 6, "name" => "Hot & Spicy", "price" => "69000", "image" => "/PIZZA/projects images/pizza-12.jpg"]
         ];

         // Loop untuk menampilkan setiap pizza
         foreach ($menus as $menu) {
      ?>
      <div class="box">
         <div class="price">Rp <?= number_format($menu["price"], 0, ',', '.'); ?></div>
         <img src="<?= $menu["image"]; ?>" alt="<?= $menu["name"]; ?>">
         <div class="name"><?= $menu["name"]; ?></div>
         <form action="" method="post">
            <input type="hidden" name="pid" value="<?= $menu["id"]; ?>">
            <input type="hidden" name="name" value="<?= $menu["name"]; ?>">
            <input type="hidden" name="price" value="<?= $menu["price"]; ?>">
            <input type="hidden" name="image" value="<?= $menu["image"]; ?>">
            <input type="number" name="qty" class="qty" min="0" max="99" value="0" onkeypress="if(this.value.length == 2) return false;">
            <input type="submit" class="btn" name="add_to_cart" value="Tambah ke Keranjang">
         </form>
      </div>
      <?php
         }
      ?>

   </div>

</section>


<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <i class="fas fa-phone"></i>
         <h3>phone number</h3>
         <p>081999186869</p>
      </div>

      <div class="box">
         <i class="fas fa-map-marker-alt"></i>
         <h3>alamat kami</h3>
         <p>Harapan Indah, Bekasi</p>
      </div>

      <div class="box">
         <i class="fas fa-clock"></i>
         <h3>jam buka</h3>
         <p>08.00-22.00</p>
      </div>

      <div class="box">
         <i class="fas fa-envelope"></i>
         <h3>email</h3>
         <p>Pizzadim@gmail.com</p>
      </div>

   </div>

   <div class="credit">
      &copy;  <?= date('Y'); ?> by <span>PizzaDim</span> 
   </div>

</section>



<!-- ulasan section starts -->
<section class="review" id="review">

   <h1 class="heading">Tinggalkan Ulasan Anda</h1>

   <!-- Container ulasan bergaya horizontal scroll -->
   <div class="box-container" style="display: flex; overflow-x: auto; gap: 1rem; padding-bottom: 1rem; scroll-snap-type: x mandatory;">
      <?php
         if ($user_id != '') {
            $get_user = $conn->prepare("SELECT name FROM user WHERE id = ?");
            $get_user->execute([$user_id]);
            $user_data = $get_user->fetch(PDO::FETCH_ASSOC);
            $user_name = $user_data['name'];
         } else {
            $user_name = '';
         }

         if (isset($_POST['submit_review'])) {
            if ($user_id == '') {
               $message[] = 'Silakan login terlebih dahulu!';
            } else {
               $review = htmlspecialchars($_POST['review'], ENT_QUOTES, 'UTF-8');
               $rating = intval($_POST['rating']);

               $insert_review = $conn->prepare("INSERT INTO ulasan (id_user, nama_pengguna, ulasan, rating) VALUES (?, ?, ?, ?)");
               $insert_review->execute([$user_id, $user_name, $review, $rating]);

               $message[] = 'Ulasan berhasil dikirim!';
            }
         }

         $get_reviews = $conn->prepare("SELECT * FROM ulasan ORDER BY id DESC");
         $get_reviews->execute();
         $reviews = $get_reviews->fetchAll(PDO::FETCH_ASSOC);

         function generateStars($rating) {
            return str_repeat('⭐', max(1, min(5, $rating)));
         }
      ?>

      <!-- Kotak-kotak ulasan -->
      <?php foreach ($reviews as $r): ?>
         <div class="box" style="flex: 0 0 250px; background: #f9f9f9; border-radius: 10px; padding: 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); scroll-snap-align: start;">
            <p style="font-weight: bold; margin-bottom: .5rem;"><?= htmlspecialchars($r['nama_pengguna']); ?></p>
            <p style="color: #ffc107; font-size: 1.2rem;"><?= generateStars($r['rating']); ?></p>
            <p style="font-style: italic; font-size: .95rem; color: #333;"><?= htmlspecialchars($r['ulasan']); ?></p>
         </div>
      <?php endforeach; ?>
   </div>

   <!-- Form ulasan -->
   <!-- Form ulasan -->
<div style="display: flex; justify-content: center; margin-top: 2rem;">
   <div class="box" style="max-width: 600px; width: 100%; background: #fff; padding: 2rem; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
      <?php if ($user_id != ''): ?>
         <form action="" method="post">
            <p><strong>Nama:</strong> <?= htmlspecialchars($user_name); ?></p>

            <label for="review">Ulasan:</label>
            <textarea name="review" id="review" rows="4" required placeholder="Tulis ulasan Anda..." style="width: 100%; padding: 1rem;"></textarea>

            <label for="rating">Rating:</label>
            <select name="rating" id="rating" required style="width: 100%; padding: 0.5rem;">
               <option value="">Pilih rating</option>
               <option value="5">5 - ⭐⭐⭐⭐⭐</option>
               <option value="4">4 - ⭐⭐⭐⭐</option>
               <option value="3">3 - ⭐⭐⭐</option>
               <option value="2">2 - ⭐⭐</option>
               <option value="1">1 - ⭐</option>
            </select>

            <input type="submit" name="submit_review" value="Kirim Ulasan" class="btn" style="margin-top: 1rem;">
         </form>
      <?php else: ?>
         <p>Silakan login terlebih dahulu untuk memberikan ulasan.</p>
      <?php endif; ?>
   </div>
</div>

</section>

<div class="help-wrapper">
   <p class="help-text">Apakah Anda mengalami masalah?</p>
   <a href="pengaduan.php" class="chat-help-btn">
      <img src="/PIZZA/admin/gambar.png" alt="Bantuan" />
      <span>Bantuan</span>
   </a>
</div>


<script src="/PIZZA/js/script.js"></script>

</body>
</html>
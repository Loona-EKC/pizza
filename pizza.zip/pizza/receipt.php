<?php
include 'config.php';
session_start();

$user_id = $_SESSION['user_id'] ?? '';

if (!$user_id) {
    echo "Tidak ada data pesanan.";
    exit;
}

$select_order = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$select_order->execute([$user_id]);

if ($select_order->rowCount() > 0) {
    $order = $select_order->fetch(PDO::FETCH_ASSOC);
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Struk Pesanan</title>
        <link rel="stylesheet" href="/PIZZA/css/receipt.css">
    </head>
    <body>
        <div class="overlay">
            <div class="receipt">
                <h2>Struk Pesanan Anda</h2>
                <p><strong>Nama:</strong> <?= htmlspecialchars($order['name']); ?></p>
                <p><strong>Nomor Telepon:</strong> <?= htmlspecialchars($order['number']); ?></p>
                <p><strong>Alamat:</strong> <?= htmlspecialchars($order['address']); ?></p>
                <p><strong>Metode Pembayaran:</strong> <?= htmlspecialchars($order['method']); ?></p>
                <p><strong>Pesanan:</strong> <?= htmlspecialchars($order['total_products']); ?></p>
                <p class="total">Total Pembayaran: Rp. <?= number_format($order['total_price'], 0, ',', '.'); ?></p>
                <a href="index.php" class="btn">Kembali ke Beranda</a>
            </div>
        </div>
    </body>
    </html>
    <?php
} else {
    echo "Tidak ada data pesanan.";
}
?>

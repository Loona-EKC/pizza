<?php
include 'config.php';
session_start();

$user_id = $_SESSION['user_id'] ?? '';
$message = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order'])) {
    $name = $_POST['name'];
    $number = $_POST['number'];
    $method = $_POST['method'];
    $flat = $_POST['flat'];
    $street = $_POST['street'];
    $pin_code = $_POST['pin_code'];

    $address = $flat . ', ' . $street . ' - ' . $pin_code;
    $total_products = $_POST['total_products'];
    $total_price = $_POST['total_price'];

    // Tentukan status pembayaran berdasarkan metode
    $payment_status = (strtolower($method) === 'cash on delivery') ? 'pending' : 'berhasil';

    // Simpan ke tabel orders
    $insert_order = $conn->prepare("INSERT INTO orders (user_id, name, number, method, address, total_products, total_price, payment_status, placed_on) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $insert_order->execute([$user_id, $name, $number, $method, $address, $total_products, $total_price, $payment_status]);

    // Hapus isi keranjang
    $delete_cart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $delete_cart->execute([$user_id]);

    // Redirect ke struk
    header("Location: receipt.php");
    exit;
}

// Ambil data keranjang
$grand_total = 0;
$total_products = '';
$cart_items = [];

$select_cart = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
$select_cart->execute([$user_id]);

if ($select_cart->rowCount() > 0) {
    while ($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)) {
        $sub_total = $fetch_cart['price'] * $fetch_cart['quantity'];
        $grand_total += $sub_total;
        $cart_items[] = $fetch_cart['name'] . ' (' . $fetch_cart['price'] . ' x ' . $fetch_cart['quantity'] . ')';
    }
    $total_products = implode(', ', $cart_items);
} else {
    $message[] = 'Keranjang Anda Kosong!';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pembayaran - PizzaDim</title>
    <link rel="stylesheet" href="/PIZZA/css/style.css">
</head>
<body>

<h1 class="heading">PESAN SEKARANG</h1>

<?php if (!empty($message)): ?>
    <?php foreach ($message as $msg): ?>
        <div class="message">
            <span><?= $msg ?></span>
            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php if ($grand_total > 0): ?>
<div class="order-wrapper">
    <div class="display-orders">
        <?php foreach ($cart_items as $item): ?>
            <p><?= htmlspecialchars($item) ?></p>
        <?php endforeach; ?>
    </div>

    <div class="grand-total">Total : <span>Rp.<?= number_format($grand_total, 0, ',', '.'); ?></span></div>

    <form action="" method="post">
        <input type="hidden" name="total_products" value="<?= htmlspecialchars($total_products); ?>">
        <input type="hidden" name="total_price" value="<?= $grand_total; ?>">

        <div class="inputBox">
            <label>Nama Anda:</label>
            <input type="text" name="name" class="box" required>
        </div>
        <div class="inputBox">
            <label>Nomor HP:</label>
            <input type="text" name="number" class="box" required maxlength="15">
        </div>
        <div class="inputBox">
            <label>Metode Pembayaran:</label>
            <select name="method" class="box">
                <option value="cash on delivery">Cash on Delivery</option>
                <option value="credit card">Credit Card</option>
                <option value="paytm">Paytm</option>
                <option value="paypal">PayPal</option>
            </select>
        </div>
        <div class="inputBox">
            <label>Alamat:</label>
            <input type="text" name="flat" class="box" required>
        </div>
        <div class="inputBox">
            <label>Kota:</label>
            <input type="text" name="street" class="box" required>
        </div>
        <div class="inputBox">
            <label>Kode Pos:</label>
            <input type="text" name="pin_code" class="box" required maxlength="6">
        </div>

        <div style="text-align: center;">
            <button type="submit" name="order" class="btn">Pesan Sekarang</button>
        </div>
    </form>
</div>
<?php else: ?>
    <div class="empty" style="text-align:center; font-size: 1.5rem; margin: 2rem;">
        <a href="menu.php" class="btn">Kembali ke Menu</a>
    </div>
<?php endif; ?>

</body>
</html>

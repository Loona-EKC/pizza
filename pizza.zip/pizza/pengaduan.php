<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Silakan login terlebih dahulu untuk mengirim pengaduan.');</script>";
    echo "<style>body {display:none;}</style>"; // Sembunyikan body konten agar form tidak bisa diakses
    exit;
}

$user_id = $_SESSION['user_id'] ?? null;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['aduan'])) {
   $aduan = htmlspecialchars($_POST['aduan'], ENT_QUOTES, 'UTF-8');

   $stmt = $conn->prepare("INSERT INTO pengaduan (id_user, aduan) VALUES (?, ?)");
   $stmt->execute([$user_id, $aduan]);

   $message = "Pengaduan berhasil dikirim!";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
   <meta charset="UTF-8">
   <title>Pengaduan</title>
   <link rel="stylesheet" href="/PIZZA/css/pengaduan.css">
</head>

<nav class="simple-navbar">
   <a href="/PIZZA/index.php" class="back-btn">← Kembali</a>
   <h1 class="navbar-title">Pengaduan</h1>
</nav>


<body>

<h2 style="text-align:center; margin-top:50px;">Form Pengaduan</h2>
<div style="max-width: 600px; margin: auto; padding: 2rem;">
   <form action="" method="post">
      <label for="aduan">Apa yang ingin Anda adukan?</label><br>
      <textarea name="aduan" id="aduan" rows="5" required style="width: 100%; padding: 1rem;"></textarea>
      <input type="submit" value="Kirim Pengaduan" class="btn" style="margin-top: 1rem;">
   </form>
</div>

</body>
</html>
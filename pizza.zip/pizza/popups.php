<?php
include 'config.php';

?>

<div class="user-account">

   <section>

      <div id="close-account"><span>Tutup</span></div>

      <div class="user">
         <?php if ($user_id): ?>

         <!-- ✅ Jika Sudah Login -->
         <div class="user">
            <?php
               $select_user = $conn->prepare("SELECT * FROM user WHERE id = ?");
               $select_user->execute([$user_id]);
               if($select_user->rowCount() > 0){
                  $fetch_user = $select_user->fetch(PDO::FETCH_ASSOC);
                  echo '<p>Username: <span>' . $fetch_user['name'] . '</span></p>';
                  echo '<p>Email: <span>' . $fetch_user['email'] . '</span></p>';
                  echo '<a href="index.php?logout" class="btn">Keluar</a>';
               }
            ?>
         </div>

      <?php else: ?>

         <!-- ❌ Jika Belum Login (Gunakan tampilan kamu yang lama) -->
         <div class="user">
            <p><span>Anda belum masuk sekarang!</span></p>
         </div>

         <div class="display-orders">
            <p><span>keranjang Anda kosong!</span></p>
         </div>

         <div class="flex">
            <form action="user_login.php" method="post">
               <h3>Login Sekarang</h3>
               <input type="email" name="email" required class="box" placeholder="Masukkan email Anda" maxlength="50">
               <input type="password" name="pass" required class="box" placeholder="Masukkan kata sandi" maxlength="20">
               <input type="submit" value="Login Sekarang" name="login" class="btn">
            </form>

            <form action="" method="post">
               <h3>Register Sekarang</h3>
               <input type="text" name="name" required class="box" placeholder="Username" maxlength="20" oninput="this.value = this.value.replace(/\s/g, '')">
               <input type="email" name="email" required class="box" placeholder="Email" maxlength="50">
               <input type="password" name="pass" required class="box" placeholder="Password" maxlength="20" oninput="this.value = this.value.replace(/\s/g, '')">
               <input type="password" name="cpass" required class="box" placeholder="Konfirmasi Password" maxlength="20" oninput="this.value = this.value.replace(/\s/g, '')">
               <input type="submit" value="Register Sekarang" name="register" class="btn">
            </form>
         </div>

      <?php endif; ?>
      </div>

      <div class="display-orders">
         <?php
            $select_cart = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
            $select_cart->execute([$user_id]);
            if($select_cart->rowCount() > 0){
               while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
                  echo '<p>'.$fetch_cart['name'].' <span>('.$fetch_cart['price'].' x '.$fetch_cart['quantity'].')</span></p>';
               }
            }else{
               echo '<p><span>keranjang Anda kosong!</span></p>';
            }
         ?>
      </div>


   </section>

</div>

<div class="my-orders">

   <section>

      <div id="close-orders"><span>close</span></div>

      <h3 class="title"> Pesananku </h3>

      <?php
         $select_orders = $conn->prepare("SELECT * FROM orders WHERE user_id = ?");
         $select_orders->execute([$user_id]);
         if($select_orders->rowCount() > 0){
            while($fetch_orders = $select_orders->fetch(PDO::FETCH_ASSOC)){   
      ?>
      <div class="box">
         <p> Ditempatkan pada : <span><?= $fetch_orders['placed_on']; ?></span> </p>
         <p> Nama : <span><?= $fetch_orders['name']; ?></span> </p>
         <p> Nomor : <span><?= $fetch_orders['number']; ?></span> </p>
         <p> Alamat : <span><?= $fetch_orders['address']; ?></span> </p>
         <p> Metode Pembayaran : <span><?= $fetch_orders['method']; ?></span> </p>
         <p> Total Pesanan : <span><?= $fetch_orders['total_products']; ?></span> </p>
         <p> Total Pembayaran : <span>$<?= $fetch_orders['total_price']; ?>/-</span> </p>
         <p> Status Pembayaran : <span style="color:<?php if($fetch_orders['payment_status'] == 'pending'){ echo 'red'; }else{ echo 'green'; }; ?>"><?= $fetch_orders['payment_status']; ?></span> </p>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">belum ada yang dipesan !</p>';
      }
      ?>

   </section>

</div>

<div class="shopping-cart">

   <section>

      <div id="close-cart"><span>Tutup</span></div>

      <?php
         $grand_total = 0;
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
              $sub_total = ($fetch_cart['price'] * $fetch_cart['quantity']);
              $grand_total += $sub_total; 
      ?>
      <div class="box">
         <a href="index.php?delete_cart_item=<?= $fetch_cart['id']; ?>" class="fas fa-times" onclick="return confirm('hapus item keranjang ini?');"></a>
         <img src="<?= $fetch_cart['image']; ?>" alt="">
         <div class="content">
          <p> <?= $fetch_cart['name']; ?> <br><span>(<?= $fetch_cart['price']; ?> x <?= $fetch_cart['quantity']; ?>)</span></p>
          <form action="" method="post">
             <input type="hidden" name="cart_id" value="<?= $fetch_cart['id']; ?>">
             <input type="number" name="qty" class="qty" min="1" max="99" value="<?= $fetch_cart['quantity']; ?>" onkeypress="if(this.value.length == 2) return false;">
               <button type="submit" class="fas fa-edit" name="update_qty"></button>
          </form>
         </div>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty"><span>keranjang Anda kosong!</span></p>';
      }
      ?>

      <div class="cart-total"> hasil akhir : <span>Rp.<?= $grand_total; ?></span></div>

      <a href="pembayaran.php" class="btn">pesan sekarang</a>

   </section>

</div>
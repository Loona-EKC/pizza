<?php
include 'connect.php';

// Handle update form
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['payment_status'];

    $stmt = $conn->prepare("UPDATE orders SET payment_status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $order_id);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Status berhasil diperbarui');</script>";
}

// Fetch pending COD orders
$result = $conn->query("SELECT * FROM orders WHERE method = 'cash on delivery' AND payment_status = 'pending'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Update Status COD</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
        }

        /* Navbar Styles */
        .navbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #333;
            padding: 10px 20px;
            color: white;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .navbar .center-title {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            font-size: 18px;
            font-weight: bold;
        }

        /* Table Styles */
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        form {
            margin: 0;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <a href="admin_page.php">Kembali</a>
        <div class="center-title">Admin - Update Status COD</div>
        <div style="width: 70px;"></div> <!-- Spacer to balance layout -->
    </div>

    <h2>Daftar Pesanan COD (Pending)</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Nomor</th>
            <th>Alamat</th>
            <th>Total</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>

        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= htmlspecialchars($row['name']); ?></td>
            <td><?= htmlspecialchars($row['number']); ?></td>
            <td><?= htmlspecialchars($row['address']); ?></td>
            <td>Rp <?= number_format($row['total_price'], 0, ',', '.'); ?></td>
            <td><?= $row['payment_status']; ?></td>
            <td>
                <form method="post">
                    <input type="hidden" name="order_id" value="<?= $row['id']; ?>">
                    <select name="payment_status" required>
                        <option value="">--Pilih--</option>
                        <option value="berhasil">Berhasil</option>
                        <option value="gagal">Gagal</option>
                    </select>
                    <button type="submit" name="update_status">Ubah</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>


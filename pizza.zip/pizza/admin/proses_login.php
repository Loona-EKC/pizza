<?php
session_start();
include 'connect.php';

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

$query = "SELECT * FROM admin WHERE username = '$username'";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if ($data) {
    if (password_verify($password, $data['password'])) {
        // ✅ Login berhasil
        $_SESSION['admin_id'] = $data['id_admin'];
        $_SESSION['admin_name'] = $data['name'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['foto'] = $data['foto'];         

        header("Location: admin_page.php");
        exit();
    } else {
        echo "<script>alert('❌ Password salah!'); window.location.href='admin_login.php';</script>";
    }
} else {
    echo "<script>alert('❌ Username tidak ditemukan!'); window.location.href='admin_login.php';</script>";
}
?>
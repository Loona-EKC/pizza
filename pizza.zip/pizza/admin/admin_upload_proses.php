<?php
include 'connect.php';

$username = mysqli_real_escape_string($conn, $_POST['username']);
$password_plain = $_POST['password'];  // password asli dari form
$name = mysqli_real_escape_string($conn, $_POST['name']);

// Hash password
$password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

// Cek apakah file foto berhasil di-upload
if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    $foto = addslashes(file_get_contents($_FILES['foto']['tmp_name']));
} else {
    die("Error upload foto profil!");
}

// Insert ke database
$query = "INSERT INTO admin (username, password, foto, name) VALUES ('$username', '$password_hashed', '$foto', '$name')";
if (mysqli_query($conn, $query)) {
    header("Location: admin_upload.php?sukses=1");
    exit();
} else {
    die("Gagal menambahkan admin: " . mysqli_error($conn));
}
?>

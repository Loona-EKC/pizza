<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Admin - CARC.ID</title>
  <link rel="stylesheet" href="/PIZZA/admin/adminstyle.css">
</head>
<body>

  <div class="wrapper">
    <form action="proses_login.php" method="post">
      <h2>Login Admin</h2>

      <div class="input-field">
        <input type="text" name="username" required>
        <label>Masukkan username admin</label>
      </div>

      <div class="input-field">
        <input type="password" name="password" required>
        <label>Masukkan password</label>
      </div>

      <div class="register">
        <p>Don't have an account? <a href="admin_upload.php">Register</a></p>
      </div>

      <button type="submit" class="submit-btn">Login</button>
    </form>
  </div>

</body>
</html>

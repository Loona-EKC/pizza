<?php
session_start();
include 'connect.php';

// Cek apakah session username sudah diset
if (!isset($_SESSION['username'])) {
    // Redirect ke login atau tampilkan error
    header("Location: /PIZZA/admin/login.php");
    exit;
}

$username = $_SESSION['username'];

// Pastikan koneksi tidak null
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$query = mysqli_query($conn, "SELECT * FROM admin WHERE username='$username'");
$data = mysqli_fetch_assoc($query);
if (!$data) {
    echo "<script>alert('Data admin tidak ditemukan'); window.location.href='/PIZZA/admin/logout.php';</script>";
    exit;
}
$nama = $data['name'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Page</title>
  <link rel="stylesheet" href="/PIZZA/admin/style.css">
</head>
<body>
  <div class="navbar">
    <h1>ADMIN</h1>

    <!-- Profil Dropdown -->
    <div class="profile-container">
      <div class="profile-name" onclick="toggleDropdown()">
        <?php echo $_SESSION['username']; ?>
      </div>
      <div class="dropdown" id="dropdownProfile">
        <img src="data:image/jpeg;base64,<?php echo base64_encode($_SESSION['foto']); ?>" alt="Foto Profil" class="profile-pic">
        <p class= "apakek"><strong><?php echo $nama; ?> </strong></p>
        <p class= "apakek1"><?php echo $_SESSION['username']; ?></p>
        <a href="/PIZZA/admin/logout.php" class="logout-btn">Logout</a>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="card">
      <a href="/PIZZA/admin/ulasan/index.php">
        <img src="/PIZZA/admin/gambar/ulasan.jpeg" alt="Ulasan Perusahaan">
        <p>ulasan perusahaan</p>
      </a>
    </div>

    <div class="card">
      <a href="/PIZZA/admin/update_status_pemesanan.php">
        <img src="/PIZZA/admin/gambar/film.jpeg" alt="Film">
        <p>film</p>
      </a>
    </div>

    <div class="card">
      <a href="/PIZZA/admin/jadwal_film/jadwal.php">
        <img src="/PIZZA/admin/gambar/jadw.jpeg" alt="Jadwal Film">
        <p>jadwal film</p>
      </a>
    </div>

    <div class="card">
      <a href="/PIZZA/admin/jadwal_film/list.php">
        <img src="/PIZZA/admin/gambar/pegawai.jpeg" alt="Daftar Pegawai">
        <p>daftar film</p>
      </a>
    </div>
  </div>

  <script>
    function toggleDropdown() {
      const dropdown = document.getElementById("dropdownProfile");
      dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    }

    window.onclick = function (event) {
      if (!event.target.matches('.profile-name')) {
        const dropdown = document.getElementById("dropdownProfile");
        if (dropdown) dropdown.style.display = "none";
      }
    }
  </script>
</body>
</html>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Admin</title>
  <link rel="stylesheet" href="/PIZZA/admin/adminupload.css">
</head>
<body>
  <div class="form-container">
    <?php if (isset($_GET['sukses']) && $_GET['sukses'] == 1): ?>
      <div class="notif-berhasil">
        ✅ Data berhasil ditambahkan!
      </div>
    <?php endif; ?>
    <h2>Tambah Admin</h2>
    <form action="admin_upload_proses.php" method="POST" enctype="multipart/form-data">
      <table>
        <tr>
          <td><label for="username">Gmail</label></td>
          <td><input type="text" name="username" id="username" required></td>
        </tr>
        <tr>
          <td><label for="password">Password</label></td>
          <td><input type="password" name="password" id="password" required></td>
        </tr>
        <tr>
          <td><label for="foto">Foto Profil</label></td>
          <td><input type="file" name="foto" id="foto" accept="image/*" required></td>
        </tr>
        <tr>
          <td><label for="name">Nama </label></td>
          <td><input type="text" name="name" id="name" required></td>
        </tr>
        <tr>
          <td colspan="2" style="text-align: center;">
            <button type="submit">Tambah Admin</button>
          </td>
        </tr>
      </table>
    </form>
  </div>
</body>
</html>